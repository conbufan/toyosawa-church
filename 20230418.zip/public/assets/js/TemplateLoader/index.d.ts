export declare const TemplateLoader: (url: string) => Promise<void | NodeListOf<ChildNode>>;
